<script type="text/javascript" src="<?php echo base_url('application\views\templates\bootstrap.min.css'); ?>?>"></script>
</body>
</html>