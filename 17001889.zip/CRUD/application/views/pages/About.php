<h2><?= $title ?></h2>
<p>This is CIblog version 1.0</p>